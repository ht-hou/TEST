package com.ex.yh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YhApplication {

    public static void main(String[] args) {
        SpringApplication.run(YhApplication.class, args);
    }

}
