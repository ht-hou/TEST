package com.ex.yh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YhApplicationTests {

    @Test
    void contextLoads() {
    }

}
