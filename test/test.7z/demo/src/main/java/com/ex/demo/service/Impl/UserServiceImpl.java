package com.ex.demo.service.Impl;

import com.ex.demo.common.MD5;
import com.ex.demo.pojo.User;
import com.ex.demo.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Override
    public void eq(User user) {
        String password = user.getPassword();
        try {
            String md5 = MD5.md5(password);
            boolean result = md5.equals("查库");
            if(result){

            }else {
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void inster(User user) {
        String password = user.getPassword();
        try {
            String md5 = MD5.md5(password);
            user.setPassword(md5);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
