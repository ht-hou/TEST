package com.ex.demo.service;

import com.ex.demo.pojo.User;

public interface UserService {

     void eq(User user);

     void inster(User user);
}
