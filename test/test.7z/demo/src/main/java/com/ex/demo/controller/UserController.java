package com.ex.demo.controller;

import com.ex.demo.pojo.User;
import com.ex.demo.service.UserService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


@RequestMapping("/user")
@RestController
public class UserController {

    @Resource
    UserService userService;

//    登录
//    查询数据库已有用户名
//    验证密码是否一致‘
//    创建token
//    校验token
    @PostMapping("/login")
    public void login(User user) {

        userService.eq(user);

        return;

    }

    @PostMapping("/register")
    public void register(User user) {
        userService.inster(user);

    }
}
