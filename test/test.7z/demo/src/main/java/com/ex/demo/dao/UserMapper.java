package com.ex.demo.dao;

import com.ex.demo.pojo.User;

public interface UserMapper {

    User getUser(String userName);
}
